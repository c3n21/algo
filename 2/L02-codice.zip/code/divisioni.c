#include <stdio.h>
#define N 10

int main( void) {
    int b, n, i = 0;
    int c[N] = {0}; 
    
    scanf( "%d %d", &n, &b );
    
    do c[i++] = n % b;
        while ( ( n /= b ) > 0 );

    while ( i > 0 )
        printf( "%d", c[--i] ); 
     
    printf( "\n" ); 
    
    return 0;
}

